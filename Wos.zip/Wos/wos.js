document.addEventListener("DOMContentLoaded", function () {
    const desktop = document.getElementById("desktop");

    function createIcon(name, onClick) {
        const icon = document.createElement("div");
        icon.classList.add("app-icon");
        icon.innerText = name;
        icon.onclick = onClick;
        desktop.appendChild(icon);
    }

    function openWindow(id) {
        document.getElementById(id).style.display = "flex";
    }

    window.closeWindow = function (id) {
        document.getElementById(id).style.display = "none";
    };

    window.changeWallpaper = function () {
        document.body.style.background = "#" + Math.floor(Math.random() * 16777215).toString(16);
    };

    function runCommand(event) {
        if (event.key === "Enter") {
            const commandInput = document.getElementById("commandInput");
            const terminalOutput = document.getElementById("terminalOutput");
            const cmd = commandInput.value.trim();

            if (cmd === "curl ascii.live/rick") {
                terminalOutput.innerText = "🎵 Never gonna give you up! 🎵";
            } else if (cmd === "curl ascii.live/parrot") {
                terminalOutput.innerText = "🦜 Dancing Parrot! 🦜";
            } else {
                terminalOutput.innerText = "Command not found";
            }
            commandInput.value = "";
        }
    }
    
    document.getElementById("commandInput").addEventListener("keydown", runCommand);

    window.performSearch = function () {
        const query = document.getElementById("aiSearchInput").value.trim();
        if (!query) return;
        document.getElementById("aiSearchResults").innerHTML = `Opening search for "<b>${query}</b>"...`;
        window.open(`https://www.bing.com/search?q=${encodeURIComponent(query)}`, "_blank");
    };

    createIcon("Terminal", () => openWindow("terminal"));
    createIcon("Settings", () => openWindow("settings"));

    createIcon("Chrome Browser", () => {
        const url = prompt("Enter URL:");
        if (url) {
            let finalUrl = url.startsWith("http") ? url : "https://" + url;
            window.open(finalUrl, "_blank", "noopener,noreferrer");
        }
    });

    createIcon("Snake Game", () => {
        window.open("snake.html", "_blank", "width=400,height=400");
    });

    createIcon("W Store", () => {
        alert("Welcome to W Store! More apps coming soon!");
    });

    createIcon("Punctuation Game", () => {
        window.open("puntuation.html", "_blank", "width=800,height=600");
    });
});
function openApp(appName) {
    if (appName === 'maze-game') {
        window.open('maze-game.html', '_blank');
    }
}
